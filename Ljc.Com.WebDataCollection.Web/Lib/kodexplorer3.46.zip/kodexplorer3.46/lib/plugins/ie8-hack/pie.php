<?php
header('Content-type: text/x-component');
include('pie.htc');
?>
